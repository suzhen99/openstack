Set up the `tempest` user

Create the tempest user and allow it to sudo.

**Role Variables**

.. zuul:rolevar:: devstack_base_dir
   :default: /opt/stack

   The devstack base directory.
